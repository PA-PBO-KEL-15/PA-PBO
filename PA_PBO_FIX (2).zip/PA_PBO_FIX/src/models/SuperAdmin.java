/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

public class SuperAdmin {
    public String Id_SuperAdmin;
    public String Username;
    public String Password;
    
    public SuperAdmin(String Id_SuperAdmin, String Username, String Password) {
        this.Id_SuperAdmin = Id_SuperAdmin;
        this.Username = Username;
        this.Password = Password;     
    }   
}
